
-- Fix search_path on set_updated_at
create or replace function public.set_updated_at()
returns trigger
language plpgsql
security invoker
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- Restrict bucket listing: only owners can list their files; objects are still served via public URL.
drop policy if exists "Avatar images are publicly accessible" on storage.objects;
drop policy if exists "Banner images are publicly accessible" on storage.objects;

create policy "Users list own avatar"
  on storage.objects for select using (
    bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]
  );
create policy "Users list own banner"
  on storage.objects for select using (
    bucket_id = 'banners' and auth.uid()::text = (storage.foldername(name))[1]
  );

-- Revoke execute from anon/authenticated on the trigger functions (only triggers should call them)
revoke all on function public.handle_new_user() from public, anon, authenticated;
revoke all on function public.set_updated_at() from public, anon, authenticated;
