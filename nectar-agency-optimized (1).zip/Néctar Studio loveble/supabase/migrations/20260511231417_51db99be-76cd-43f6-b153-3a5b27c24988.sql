
-- PROFILES
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  bio text default '',
  avatar_url text,
  banner_url text,
  social_links jsonb not null default '{}'::jsonb,
  category text default 'Geral',
  profile_color text not null default '#FFD600',
  profile_theme text not null default 'light',
  plan text not null default 'Free',
  ads_used integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Profiles are viewable by everyone"
  on public.profiles for select using (true);

create policy "Users can insert own profile"
  on public.profiles for insert with check (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id);

-- updated_at trigger
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, username)
  values (
    new.id,
    coalesce(
      new.raw_user_meta_data ->> 'username',
      new.raw_user_meta_data ->> 'name',
      split_part(new.email, '@', 1)
    )
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- ADS
create table public.ads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text not null default '',
  category text not null default 'Geral',
  image_url text,
  link_url text,
  views integer not null default 0,
  ctr numeric not null default 0,
  vip boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.ads enable row level security;

create policy "Ads viewable by everyone"
  on public.ads for select using (true);

create policy "Users can insert own ads"
  on public.ads for insert with check (auth.uid() = user_id);

create policy "Users can update own ads"
  on public.ads for update using (auth.uid() = user_id);

create policy "Users can delete own ads"
  on public.ads for delete using (auth.uid() = user_id);

create trigger ads_updated_at
before update on public.ads
for each row execute function public.set_updated_at();

-- STORAGE BUCKETS
insert into storage.buckets (id, name, public) values ('avatars','avatars', true);
insert into storage.buckets (id, name, public) values ('banners','banners', true);

create policy "Avatar images are publicly accessible"
  on storage.objects for select using (bucket_id = 'avatars');
create policy "Users upload own avatar"
  on storage.objects for insert with check (
    bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]
  );
create policy "Users update own avatar"
  on storage.objects for update using (
    bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]
  );
create policy "Users delete own avatar"
  on storage.objects for delete using (
    bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]
  );

create policy "Banner images are publicly accessible"
  on storage.objects for select using (bucket_id = 'banners');
create policy "Users upload own banner"
  on storage.objects for insert with check (
    bucket_id = 'banners' and auth.uid()::text = (storage.foldername(name))[1]
  );
create policy "Users update own banner"
  on storage.objects for update using (
    bucket_id = 'banners' and auth.uid()::text = (storage.foldername(name))[1]
  );
create policy "Users delete own banner"
  on storage.objects for delete using (
    bucket_id = 'banners' and auth.uid()::text = (storage.foldername(name))[1]
  );
