import * as React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Copy, UploadCloud, CheckCircle2, Loader2, QrCode, Mail, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { PlanBadge } from "@/components/PlanBadge";
import type { PlanDef } from "@/lib/plans";

const PIX_KEY = "maiconsantospaz911@gmail.com";

export function PaymentDialog({
  plan,
  open,
  onOpenChange,
}: {
  plan: PlanDef | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { user, profile } = useAuth();
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [file, setFile] = React.useState<File | null>(null);
  const [submitting, setSubmitting] = React.useState(false);
  const [done, setDone] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setName(profile?.username ?? "");
      setEmail(user?.email ?? "");
      setFile(null);
      setDone(false);
    }
  }, [open, profile, user]);

  if (!plan) return null;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(PIX_KEY);
      toast.success("Chave PIX copiada");
    } catch {
      toast.error("Não foi possível copiar");
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return toast.error("Faça login para continuar");
    if (!name.trim() || !email.trim()) return toast.error("Preencha nome e email");
    if (!file) return toast.error("Anexe o comprovante");

    setSubmitting(true);
    try {
      const ext = file.name.split(".").pop() || "png";
      const path = `${user.id}/${Date.now()}.${ext}`;
      const up = await supabase.storage.from("receipts").upload(path, file, {
        cacheControl: "3600",
        upsert: false,
        contentType: file.type || undefined,
      });
      if (up.error) throw up.error;
      const { data: pub } = supabase.storage.from("receipts").getPublicUrl(path);
      const receipt_url = pub.publicUrl;

      const { error } = await supabase.from("payments").insert({
        user_id: user.id,
        full_name: name.trim(),
        email: email.trim(),
        plan: plan.name,
        receipt_url,
        status: "pending",
      });
      if (error) throw error;

      setDone(true);
      toast.success("Comprovante enviado!");
    } catch (err: any) {
      toast.error(err?.message ?? "Erro ao enviar comprovante");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-primary glow-yellow">
              <QrCode className="h-4 w-4" />
            </span>
            Pagamento via PIX
          </DialogTitle>
          <DialogDescription>
            Confirme seu plano, faça o PIX e envie o comprovante para liberar.
          </DialogDescription>
        </DialogHeader>

        {done ? (
          <div className="flex flex-col items-center gap-3 py-8 text-center">
            <span className="grid h-14 w-14 place-items-center rounded-full bg-emerald-100 text-emerald-600">
              <CheckCircle2 className="h-7 w-7" />
            </span>
            <h3 className="text-lg font-bold">Comprovante recebido</h3>
            <p className="max-w-sm text-sm text-muted-foreground">
              Após o envio, aguarde a aprovação manual da equipe Néctar. Seu plano será ativado em instantes.
            </p>
            <Button className="mt-2" onClick={() => onOpenChange(false)}>Fechar</Button>
          </div>
        ) : (
          <div className="space-y-5">
            <div className="rounded-2xl border bg-gradient-to-br from-secondary/40 via-background to-background p-4">
              <div className="flex items-center justify-between">
                <PlanBadge plan={plan.name} size="lg" />
                <div className="text-right">
                  <div className="text-2xl font-extrabold">
                    R${plan.price.toFixed(2).replace(".", ",")}
                  </div>
                  <div className="text-xs text-muted-foreground">por mês</div>
                </div>
              </div>
              <div className="mt-4 rounded-xl border border-dashed bg-card p-3">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Chave PIX (email)</div>
                <div className="mt-1 flex items-center gap-2">
                  <Mail className="h-4 w-4 text-primary shrink-0" />
                  <code className="flex-1 truncate text-sm font-medium">{PIX_KEY}</code>
                  <Button type="button" size="sm" variant="outline" onClick={copy}>
                    <Copy className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
              <div className="mt-3 flex items-start gap-2 rounded-lg bg-amber-50 p-2 text-xs text-amber-800 dark:bg-amber-950/40 dark:text-amber-200">
                <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span>Faça o PIX do valor exato e envie o comprovante abaixo.</span>
              </div>
            </div>

            <form onSubmit={submit} className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label className="text-xs">Nome completo</Label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} required maxLength={120} />
                </div>
                <div>
                  <Label className="text-xs">Email</Label>
                  <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required maxLength={160} />
                </div>
              </div>
              <div>
                <Label className="text-xs">ID do usuário</Label>
                <Input value={user?.id ?? ""} readOnly className="font-mono text-xs" />
              </div>
              <div>
                <Label className="text-xs">Comprovante</Label>
                <label className="mt-1 flex cursor-pointer items-center gap-3 rounded-lg border border-dashed bg-muted/30 p-3 hover:bg-muted/50 transition-colors">
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-secondary text-primary">
                    <UploadCloud className="h-4 w-4" />
                  </span>
                  <span className="flex-1 truncate text-sm">
                    {file ? file.name : "Selecionar imagem ou PDF"}
                  </span>
                  {file && <Badge variant="secondary">{(file.size / 1024).toFixed(0)} KB</Badge>}
                  <input
                    type="file"
                    accept="image/*,application/pdf"
                    className="hidden"
                    onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                  />
                </label>
              </div>

              <Button type="submit" disabled={submitting} className="h-11 w-full text-base font-semibold">
                {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                Enviar comprovante
              </Button>
              <p className="text-center text-[11px] text-muted-foreground">
                Após o envio, aguarde a aprovação manual da equipe Néctar.
              </p>
            </form>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
