import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Logo } from "./Logo";
import { useAuth } from "@/lib/auth";

export function SiteHeader() {
  const { user } = useAuth();
  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Logo />
        <nav className="hidden items-center gap-8 md:flex">
          <a href="#anuncios" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Anúncios
          </a>
          <a href="#categorias" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Categorias
          </a>
          <a href="#planos" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Planos VIP
          </a>
        </nav>
        <div className="flex items-center gap-2">
          {user ? (
            <Button asChild variant="glow" size="sm">
              <Link to="/app">Acessar painel</Link>
            </Button>
          ) : (
            <>
              <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex">
                <Link to="/login">Entrar</Link>
              </Button>
              <Button asChild variant="glow" size="sm">
                <Link to="/login">Começar grátis</Link>
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
