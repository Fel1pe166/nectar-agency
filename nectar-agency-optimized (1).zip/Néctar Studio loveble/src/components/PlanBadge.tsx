import { getPlan } from "@/lib/plans";
import { cn } from "@/lib/utils";

export function PlanBadge({
  plan,
  size = "md",
  className,
}: {
  plan: string | null | undefined;
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const p = getPlan(plan);
  const Icon = p.badge.icon;
  const sizing =
    size === "sm"
      ? "px-2 py-0.5 text-[11px] gap-1"
      : size === "lg"
        ? "px-3.5 py-1.5 text-sm gap-1.5"
        : "px-2.5 py-1 text-xs gap-1";
  const iconSize = size === "lg" ? "h-3.5 w-3.5" : "h-3 w-3";
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full font-semibold tracking-wide",
        sizing,
        p.badge.className,
        className,
      )}
    >
      <Icon className={iconSize} />
      {p.badge.label}
    </span>
  );
}
