import { Instagram, Twitter, Youtube, Linkedin } from "lucide-react";
import { Logo } from "./Logo";

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60 bg-background">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4">
        <div className="space-y-4 md:col-span-2">
          <Logo />
          <p className="max-w-sm text-sm text-muted-foreground">
            A plataforma definitiva para publicidade, divulgação e crescimento digital.
          </p>
          <div className="flex gap-3">
            {[Instagram, Twitter, Youtube, Linkedin].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="grid h-9 w-9 place-items-center rounded-full border border-border text-muted-foreground transition-colors hover:bg-primary hover:text-primary-foreground hover:border-primary"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold">Plataforma</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><a href="#anuncios" className="hover:text-foreground">Anúncios</a></li>
            <li><a href="#categorias" className="hover:text-foreground">Categorias</a></li>
            <li><a href="#planos" className="hover:text-foreground">Planos VIP</a></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-semibold">Empresa</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><a href="#" className="hover:text-foreground">Sobre</a></li>
            <li><a href="#" className="hover:text-foreground">Contato</a></li>
            <li><a href="#" className="hover:text-foreground">Termos</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/60">
        <div className="mx-auto max-w-7xl px-4 py-5 text-center text-xs text-muted-foreground sm:px-6">
          © 2026 Néctar Agency. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
}
