import { Link, useNavigate } from "@tanstack/react-router";
import * as React from "react";

export function Logo({ className = "" }: { className?: string }) {
  const navigate = useNavigate();
  const clicksRef = React.useRef<number[]>([]);

  const handleClick = (e: React.MouseEvent) => {
    const now = Date.now();
    clicksRef.current = clicksRef.current.filter((t) => now - t < 2500);
    clicksRef.current.push(now);
    if (clicksRef.current.length >= 5) {
      e.preventDefault();
      clicksRef.current = [];
      navigate({ to: "/admin-secret" });
    }
  };

  return (
    <Link
      to="/"
      onClick={handleClick}
      className={`group inline-flex items-center gap-2 select-none ${className}`}
    >
      <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-secondary text-primary shadow-elegant transition-transform group-hover:-rotate-6">
        <span className="text-lg font-black">N</span>
        <span className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full bg-primary glow-yellow" />
      </span>
      <span className="text-lg font-extrabold tracking-tight">
        Néctar <span className="text-muted-foreground font-medium">Agency</span>
      </span>
    </Link>
  );
}
