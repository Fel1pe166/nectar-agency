import { Eye, MousePointerClick, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Ad } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

export function AdCard({ ad }: { ad: Ad }) {
  return (
    <article
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-2xl border bg-card card-hover",
        ad.vip ? "border-primary/40 glow-yellow" : "border-border",
      )}
    >
      {ad.vip && (
        <div className="absolute right-3 top-3 z-10">
          <Badge className="gap-1 bg-primary text-primary-foreground shadow-glow">
            <Sparkles className="h-3 w-3" /> VIP
          </Badge>
        </div>
      )}
      <div className="aspect-[16/10] overflow-hidden bg-muted">
        <img
          src={ad.image}
          alt={ad.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="flex flex-1 flex-col gap-3 p-5">
        <Badge variant="secondary" className="w-fit rounded-full text-xs font-medium">
          {ad.category}
        </Badge>
        <h3 className="text-lg font-semibold leading-snug">{ad.title}</h3>
        <p className="line-clamp-2 text-sm text-muted-foreground">{ad.description}</p>
        <div className="mt-1 flex items-center gap-4 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <Eye className="h-3.5 w-3.5" /> {ad.views.toLocaleString("pt-BR")}
          </span>
          <span className="inline-flex items-center gap-1">
            <MousePointerClick className="h-3.5 w-3.5" /> {ad.ctr}% CTR
          </span>
        </div>
        <Button variant={ad.vip ? "glow" : "dark"} className="mt-2 w-full">
          Ver anúncio
        </Button>
      </div>
    </article>
  );
}
