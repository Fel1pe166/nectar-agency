// Plan definitions, limits and badge styling.
import { Crown, Sparkles, Rocket, Star, Zap } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export type PlanName = "Free" | "Basic" | "Pro" | "Popular" | "Avancado";

export type PlanDef = {
  name: PlanName;
  label: string;
  price: number;
  adLimit: number; // -1 = unlimited
  features: string[];
  cta: string;
  popular?: boolean;
  badge: {
    label: string;
    icon: LucideIcon;
    className: string; // tailwind classes for the badge pill
  };
};

export const PLANS: PlanDef[] = [
  {
    name: "Free",
    label: "Grátis",
    price: 0,
    adLimit: 1,
    features: ["1 anúncio ativo", "Sem destaque", "Estatísticas básicas"],
    cta: "Plano atual",
    badge: {
      label: "Grátis",
      icon: Star,
      className: "bg-muted text-muted-foreground border border-border",
    },
  },
  {
    name: "Basic",
    label: "Basic",
    price: 5,
    adLimit: 5,
    features: ["5 anúncios ativos", "Destaque simples", "Suporte por email"],
    cta: "Assinar Basic",
    badge: {
      label: "Basic",
      icon: Sparkles,
      className: "bg-primary/15 text-foreground border border-primary/40",
    },
  },
  {
    name: "Pro",
    label: "Pro",
    price: 12.9,
    adLimit: 15,
    features: [
      "15 anúncios ativos",
      "Prioridade média",
      "Badge especial",
      "Estatísticas avançadas",
    ],
    cta: "Assinar Pro",
    badge: {
      label: "Pro",
      icon: Rocket,
      className: "bg-blue-500 text-white border border-blue-400 shadow-sm",
    },
  },
  {
    name: "Popular",
    label: "Mais Popular",
    price: 19.99,
    adLimit: 35,
    popular: true,
    features: [
      "35 anúncios ativos",
      "Destaque VIP",
      "Mais visualizações",
      "Banner personalizado",
    ],
    cta: "Assinar Popular",
    badge: {
      label: "Popular",
      icon: Crown,
      className:
        "bg-gradient-to-r from-amber-300 to-yellow-500 text-secondary border border-amber-400 shadow-glow",
    },
  },
  {
    name: "Avancado",
    label: "Avançado",
    price: 49,
    adLimit: -1,
    features: [
      "Anúncios ilimitados",
      "Destaque máximo",
      "Badge premium animada",
      "Prioridade total",
    ],
    cta: "Assinar Avançado",
    badge: {
      label: "Avançado",
      icon: Zap,
      className:
        "bg-secondary text-primary border border-primary/60 glow-yellow animate-pulse",
    },
  },
];

export function getPlan(name: string | null | undefined): PlanDef {
  return PLANS.find((p) => p.name === (name as PlanName)) ?? PLANS[0];
}

export function planLimitText(plan: PlanDef, used: number) {
  return plan.adLimit === -1
    ? `${used} / ∞`
    : `${used} / ${plan.adLimit}`;
}

export function canCreateAd(plan: PlanDef, used: number) {
  return plan.adLimit === -1 || used < plan.adLimit;
}
