export type Ad = {
  id: string;
  title: string;
  description: string;
  category: string;
  image: string;
  views: number;
  ctr: number;
  vip?: boolean;
  link?: string;
};

export const categories = [
  { name: "WhatsApp", icon: "MessageCircle", color: "from-emerald-400 to-emerald-600" },
  { name: "Discord", icon: "Hash", color: "from-indigo-400 to-indigo-600" },
  { name: "Instagram", icon: "Instagram", color: "from-pink-400 to-rose-600" },
  { name: "TikTok", icon: "Music2", color: "from-slate-700 to-slate-900" },
  { name: "Produtos", icon: "ShoppingBag", color: "from-amber-400 to-orange-600" },
  { name: "Serviços", icon: "Briefcase", color: "from-sky-400 to-blue-600" },
];

const img = (q: string) =>
  `https://images.unsplash.com/${q}?auto=format&fit=crop&w=800&q=70`;

export const ads: Ad[] = [
  {
    id: "1",
    title: "Comunidade Premium WhatsApp",
    description: "Entre na maior comunidade de marketing digital do Brasil.",
    category: "WhatsApp",
    image: img("photo-1611162617213-7d7a39e9b1d7"),
    views: 12480,
    ctr: 7.2,
    vip: true,
  },
  {
    id: "2",
    title: "Servidor Discord Gamer",
    description: "Mais de 50 mil membros ativos discutindo os melhores games.",
    category: "Discord",
    image: img("photo-1614680376573-df3480f0c6ff"),
    views: 8420,
    ctr: 5.4,
  },
  {
    id: "3",
    title: "Loja Oficial — Produtos Premium",
    description: "Aproveite descontos exclusivos em itens selecionados.",
    category: "Produtos",
    image: img("photo-1483985988355-763728e1935b"),
    views: 21200,
    ctr: 9.1,
    vip: true,
  },
  {
    id: "4",
    title: "Perfil Instagram em Crescimento",
    description: "Conteúdo viral diário sobre empreendedorismo digital.",
    category: "Instagram",
    image: img("photo-1611605698335-8b1569810432"),
    views: 5340,
    ctr: 4.2,
  },
  {
    id: "5",
    title: "Dancinha Viral TikTok",
    description: "Acompanhe os melhores criadores de conteúdo do momento.",
    category: "TikTok",
    image: img("photo-1611162616305-c69b3fa7fbe0"),
    views: 18900,
    ctr: 8.6,
  },
  {
    id: "6",
    title: "Consultoria de Marketing",
    description: "Estratégias premium para escalar seu negócio digital.",
    category: "Serviços",
    image: img("photo-1552664730-d307ca884978"),
    views: 4120,
    ctr: 6.8,
    vip: true,
  },
];

export const plans = [
  {
    name: "Básico",
    price: 29,
    features: ["Até 3 anúncios ativos", "Estatísticas básicas", "Suporte por email"],
    cta: "Assinar",
  },
  {
    name: "Pro",
    price: 79,
    features: [
      "Até 10 anúncios ativos",
      "Destaque em categorias",
      "Estatísticas avançadas",
      "Suporte prioritário",
    ],
    cta: "Assinar",
  },
  {
    name: "Premium",
    price: 149,
    popular: true,
    features: [
      "Anúncios ilimitados",
      "Badge VIP em todos anúncios",
      "Glow amarelo destacado",
      "Prioridade máxima",
      "Suporte 24/7",
    ],
    cta: "Assinar Premium",
  },
];
