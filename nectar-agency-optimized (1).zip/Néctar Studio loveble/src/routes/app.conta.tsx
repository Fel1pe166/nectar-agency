import { createFileRoute, useNavigate } from "@tanstack/react-router";
import * as React from "react";
import { Camera, Image as ImageIcon, LogOut, Loader2, Link2, Instagram, Twitter, Globe, Youtube } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { PlanBadge } from "@/components/PlanBadge";
import { getPlan, planLimitText } from "@/lib/plans";

export const Route = createFileRoute("/app/conta")({
  component: Conta,
});

const CATEGORIES = ["Geral", "WhatsApp", "Discord", "Instagram", "TikTok", "Produtos", "Serviços"];
const COLORS = ["#FFD600", "#3B82F6", "#10B981", "#EF4444", "#8B5CF6", "#F97316", "#EC4899", "#0F172A"];

type SocialLinks = { instagram?: string; twitter?: string; youtube?: string; website?: string };

function Conta() {
  const { user, profile, updateProfile, logout, refreshProfile } = useAuth();
  const navigate = useNavigate();

  const [local, setLocal] = React.useState({
    username: "",
    bio: "",
    category: "Geral",
    profile_color: "#FFD600",
    profile_theme: "light",
  });
  const [social, setSocial] = React.useState<SocialLinks>({});
  const [uploading, setUploading] = React.useState<"avatar" | "banner" | null>(null);
  const saveTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const [savedAt, setSavedAt] = React.useState<number | null>(null);
  const initialized = React.useRef(false);

  // Hydrate from profile once
  React.useEffect(() => {
    if (!profile || initialized.current) return;
    initialized.current = true;
    setLocal({
      username: profile.username,
      bio: profile.bio ?? "",
      category: profile.category ?? "Geral",
      profile_color: profile.profile_color,
      profile_theme: profile.profile_theme,
    });
    const links = (profile.social_links ?? {}) as SocialLinks;
    setSocial(links);
  }, [profile]);

  // Debounced auto-save
  const queueSave = React.useCallback(
    (patch: Record<string, unknown>) => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(async () => {
        try {
          await updateProfile(patch);
          setSavedAt(Date.now());
        } catch (e: any) {
          toast.error(e?.message ?? "Erro ao salvar");
        }
      }, 600);
    },
    [updateProfile],
  );

  const updateLocal = (patch: Partial<typeof local>) => {
    setLocal((prev) => {
      const next = { ...prev, ...patch };
      queueSave(patch);
      return next;
    });
  };

  const updateSocial = (key: keyof SocialLinks, value: string) => {
    setSocial((prev) => {
      const next = { ...prev, [key]: value };
      queueSave({ social_links: next });
      return next;
    });
  };

  const handleUpload = async (file: File, kind: "avatar" | "banner") => {
    if (!user) return;
    if (file.size > 5 * 1024 * 1024) return toast.error("Arquivo muito grande (máx 5MB)");
    setUploading(kind);
    try {
      const bucket = kind === "avatar" ? "avatars" : "banners";
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${user.id}/${kind}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from(bucket)
        .upload(path, file, { upsert: true, contentType: file.type });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from(bucket).getPublicUrl(path);
      await updateProfile(kind === "avatar" ? { avatar_url: pub.publicUrl } : { banner_url: pub.publicUrl });
      setSavedAt(Date.now());
      toast.success(kind === "avatar" ? "Foto atualizada" : "Banner atualizado");
    } catch (e: any) {
      toast.error(e?.message ?? "Erro no upload");
    } finally {
      setUploading(null);
    }
  };

  if (!user || !profile) {
    return <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  }

  const plan = getPlan(profile.plan);
  const initial = (local.username || "U").slice(0, 1).toUpperCase();
  const themeBg = local.profile_theme === "dark" ? "bg-secondary text-secondary-foreground" : "bg-card";

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Minha Conta</h1>
        <p className="mt-1 text-muted-foreground">
          Personalize seu perfil. Tudo é salvo automaticamente.{" "}
          {savedAt && <span className="text-emerald-600">✓ Salvo</span>}
        </p>
      </div>

      {/* Discord-style profile card */}
      <div className={`relative overflow-hidden rounded-3xl border ${themeBg} shadow-elegant`}>
        {/* Banner */}
        <div
          className="relative h-44 sm:h-56 w-full"
          style={{
            backgroundColor: local.profile_color,
            backgroundImage: profile.banner_url ? `url(${profile.banner_url})` : undefined,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        >
          <label className="absolute right-4 top-4 inline-flex cursor-pointer items-center gap-2 rounded-full bg-black/50 px-3 py-1.5 text-xs font-medium text-white backdrop-blur hover:bg-black/70">
            {uploading === "banner" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ImageIcon className="h-3.5 w-3.5" />}
            Trocar banner
            <input
              type="file" accept="image/*" className="hidden"
              onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0], "banner")}
            />
          </label>
        </div>

        {/* Avatar + plan */}
        <div className="relative px-6 pb-6 sm:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4 -mt-12 sm:-mt-16">
            <div className="relative">
              <Avatar className="h-24 w-24 sm:h-32 sm:w-32 border-4 border-background shadow-lg">
                {profile.avatar_url && <AvatarImage src={profile.avatar_url} />}
                <AvatarFallback className="bg-secondary text-primary text-3xl font-bold">{initial}</AvatarFallback>
              </Avatar>
              <label className="absolute bottom-1 right-1 inline-flex cursor-pointer items-center justify-center rounded-full bg-primary p-2 text-primary-foreground shadow-glow hover:scale-110 transition-transform">
                {uploading === "avatar" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Camera className="h-3.5 w-3.5" />}
                <input
                  type="file" accept="image/*" className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0], "avatar")}
                />
              </label>
            </div>
            <div className="flex flex-col items-end gap-2 mt-12 sm:mt-16">
              <PlanBadge plan={profile.plan} size="lg" />
              <p className="text-xs text-muted-foreground">{planLimitText(plan, profile.ads_used)} anúncios usados</p>
            </div>
          </div>

          <div className="mt-4">
            <h2 className="text-2xl font-bold">{local.username || "Sem nome"}</h2>
            <p className="text-sm text-muted-foreground">{user.email}</p>
            {local.bio && <p className="mt-3 text-sm whitespace-pre-wrap">{local.bio}</p>}
          </div>
        </div>
      </div>

      {/* Edit forms */}
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border bg-card p-6 lg:col-span-2 space-y-5">
          <h3 className="text-lg font-semibold">Informações do perfil</h3>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="username">Nome de usuário</Label>
              <Input
                id="username" value={local.username} maxLength={50}
                onChange={(e) => updateLocal({ username: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Categoria principal</Label>
              <Select value={local.category} onValueChange={(v) => updateLocal({ category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="bio">Biografia</Label>
            <Textarea
              id="bio" rows={4} value={local.bio} maxLength={500}
              onChange={(e) => updateLocal({ bio: e.target.value })}
              placeholder="Fale um pouco sobre você ou o seu projeto..."
            />
            <p className="text-xs text-muted-foreground">{local.bio.length}/500</p>
          </div>

          <div className="space-y-3">
            <Label>Links sociais</Label>
            <div className="grid gap-3 sm:grid-cols-2">
              {[
                { key: "instagram" as const, icon: Instagram, ph: "instagram.com/voce" },
                { key: "twitter" as const, icon: Twitter, ph: "twitter.com/voce" },
                { key: "youtube" as const, icon: Youtube, ph: "youtube.com/@voce" },
                { key: "website" as const, icon: Globe, ph: "https://seu-site.com" },
              ].map(({ key, icon: Icon, ph }) => (
                <div key={key} className="relative">
                  <Icon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    className="pl-9" placeholder={ph} maxLength={200}
                    value={social[key] ?? ""}
                    onChange={(e) => updateSocial(key, e.target.value)}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="rounded-2xl border bg-card p-6">
            <h3 className="text-lg font-semibold">Aparência</h3>
            <p className="mt-1 text-xs text-muted-foreground">Cor e tema do seu perfil.</p>

            <div className="mt-4">
              <Label className="mb-2 block">Cor do perfil</Label>
              <div className="flex flex-wrap gap-2">
                {COLORS.map((c) => (
                  <button
                    key={c} type="button"
                    onClick={() => updateLocal({ profile_color: c })}
                    className={`h-9 w-9 rounded-full border-2 transition-transform hover:scale-110 ${
                      local.profile_color === c ? "border-foreground scale-110" : "border-border"
                    }`}
                    style={{ backgroundColor: c }}
                    aria-label={`Cor ${c}`}
                  />
                ))}
              </div>
            </div>

            <div className="mt-5">
              <Label className="mb-2 block">Tema</Label>
              <div className="grid grid-cols-2 gap-2">
                {(["light", "dark"] as const).map((t) => (
                  <button
                    key={t} type="button"
                    onClick={() => updateLocal({ profile_theme: t })}
                    className={`rounded-xl border p-3 text-sm font-medium transition-colors ${
                      local.profile_theme === t
                        ? "border-primary bg-primary/10"
                        : "border-border hover:bg-accent"
                    }`}
                  >
                    {t === "light" ? "Claro" : "Escuro"}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <Button
            variant="outline" className="w-full"
            onClick={async () => {
              await logout();
              toast.success("Sessão encerrada");
              navigate({ to: "/" });
            }}
          >
            <LogOut className="mr-1 h-4 w-4" /> Sair da conta
          </Button>

          <button onClick={() => refreshProfile()} className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1">
            <Link2 className="h-3 w-3" /> Recarregar perfil
          </button>
        </div>
      </div>
    </div>
  );
}
