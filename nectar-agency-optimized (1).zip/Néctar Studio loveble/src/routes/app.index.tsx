import { createFileRoute, Link } from "@tanstack/react-router";
import * as React from "react";
import { Eye, MousePointerClick, Megaphone, Crown, ArrowUpRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/lib/auth";
import { useCountUp } from "@/hooks/use-count-up";
import { supabase } from "@/integrations/supabase/client";
import { getPlan, planLimitText } from "@/lib/plans";
import { PlanBadge } from "@/components/PlanBadge";
import type { Tables } from "@/integrations/supabase/types";

export const Route = createFileRoute("/app/")({
  component: DashboardHome,
});

type Stat = {
  label: string;
  target: number;
  trend: string;
  icon: typeof Eye;
  format?: (n: number) => string;
};

function StatCard({ s, i }: { s: Stat; i: number }) {
  const v = useCountUp(s.target);
  return (
    <div
      className="group relative overflow-hidden rounded-2xl border bg-card p-6 card-hover animate-fade-in-up"
      style={{ animationDelay: `${i * 80}ms` }}
    >
      <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary/25 blur-3xl opacity-70 transition-opacity group-hover:opacity-100" />
      <div className="absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-primary to-transparent" />
      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">{s.label}</p>
          <p className="mt-3 text-4xl font-extrabold tracking-tight">{s.format ? s.format(v) : Math.round(v)}</p>
          <p className="mt-1 text-xs font-medium text-emerald-600">{s.trend}</p>
        </div>
        <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary text-primary-foreground glow-yellow transition-transform group-hover:scale-110">
          <s.icon className="h-5 w-5" />
        </span>
      </div>
    </div>
  );
}

function DashboardHome() {
  const { user, profile } = useAuth();
  const [ads, setAds] = React.useState<Tables<"ads">[]>([]);

  React.useEffect(() => {
    if (!user) return;
    supabase
      .from("ads")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(4)
      .then(({ data }) => setAds(data ?? []));
  }, [user]);

  const plan = getPlan(profile?.plan);
  const used = profile?.ads_used ?? 0;
  const totalViews = ads.reduce((acc, a) => acc + (a.views || 0), 0);
  const avgCtr = ads.length ? ads.reduce((acc, a) => acc + Number(a.ctr || 0), 0) / ads.length : 0;
  const usagePct = plan.adLimit === -1 ? 100 : Math.min(100, Math.round((used / plan.adLimit) * 100));

  const stats: Stat[] = [
    { label: "Visualizações", target: totalViews, trend: "Total acumulado", icon: Eye, format: (n) => Math.round(n).toLocaleString("pt-BR") },
    { label: "Anúncios ativos", target: used, trend: planLimitText(plan, used), icon: Megaphone, format: (n) => Math.round(n).toString() },
    { label: "CTR médio", target: avgCtr, trend: "Cliques / impressões", icon: MousePointerClick, format: (n) => `${n.toFixed(1)}%` },
  ];

  return (
    <div className="space-y-8">
      <div className="relative overflow-hidden rounded-3xl border bg-hero p-6 sm:p-10 animate-fade-in-up">
        <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-primary/40 blur-3xl" />
        <div className="absolute -left-16 bottom-0 h-40 w-40 rounded-full bg-primary/20 blur-3xl" />
        <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-2xl">
            <div className="mb-4 flex items-center gap-3 flex-wrap">
              <span className="relative grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-primary shadow-elegant animate-float">
                <span className="text-xl font-black">N</span>
                <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full bg-primary glow-yellow" />
              </span>
              <Badge variant="secondary" className="rounded-full">Bem-vindo, {profile?.username ?? "..."}</Badge>
              <PlanBadge plan={profile?.plan} />
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-balance">
              NÉCTAR AGENCY <span className="inline-block animate-float">🍯</span>
            </h1>
            <p className="mt-3 max-w-xl text-balance text-base text-muted-foreground sm:text-lg">
              A plataforma perfeita para divulgar produtos, serviços e comunidades com mais alcance, visibilidade e crescimento digital.
            </p>
          </div>
          <Button asChild variant="glow" size="lg" className="self-start lg:self-auto">
            <Link to="/app/criar"><Sparkles className="mr-1 h-4 w-4" /> Criar anúncio</Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map((s, i) => <StatCard key={s.label} s={s} i={i} />)}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border bg-card p-6 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Uso do plano</h2>
              <p className="text-sm text-muted-foreground">{planLimitText(plan, used)} anúncios utilizados</p>
            </div>
            <PlanBadge plan={profile?.plan} size="lg" />
          </div>
          <Progress value={usagePct} className="h-3" />
          <div className="mt-6 grid grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Plano atual</p>
              <p className="font-semibold">{plan.label}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Limite</p>
              <p className="font-semibold">{plan.adLimit === -1 ? "Ilimitado" : `${plan.adLimit} anúncios`}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Restante</p>
              <p className="font-semibold">{plan.adLimit === -1 ? "∞" : Math.max(0, plan.adLimit - used)}</p>
            </div>
          </div>
        </div>

        <div className="relative overflow-hidden rounded-2xl border bg-secondary p-6 text-secondary-foreground">
          <div className="absolute -right-10 -top-10 h-44 w-44 rounded-full bg-primary/40 blur-3xl" />
          <Crown className="h-8 w-8 text-primary" />
          <h3 className="mt-4 text-xl font-bold">Faça upgrade</h3>
          <p className="mt-2 text-sm text-secondary-foreground/70">
            Mais anúncios, destaque VIP e prioridade total.
          </p>
          <Button asChild variant="glow" className="mt-5 w-full">
            <Link to="/app/planos">
              Ver planos <ArrowUpRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>

      <div className="rounded-2xl border bg-card p-6">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Seus anúncios recentes</h2>
          <Button asChild variant="ghost" size="sm">
            <Link to="/app/anuncios">Ver todos</Link>
          </Button>
        </div>
        {ads.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted-foreground">
            Você ainda não criou nenhum anúncio. <Link to="/app/criar" className="text-primary underline">Criar agora</Link>
          </p>
        ) : (
          <div className="divide-y">
            {ads.map((a) => (
              <div key={a.id} className="flex items-center gap-4 py-4">
                {a.image_url ? (
                  <img src={a.image_url} alt="" className="h-14 w-20 shrink-0 rounded-lg object-cover" loading="lazy" />
                ) : (
                  <div className="h-14 w-20 shrink-0 rounded-lg bg-muted" />
                )}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="truncate font-medium">{a.title}</p>
                    {a.vip && <Badge className="bg-primary text-primary-foreground"><Sparkles className="mr-1 h-3 w-3" />VIP</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground">{a.category}</p>
                </div>
                <div className="hidden text-right text-sm sm:block">
                  <p className="font-semibold">{a.views.toLocaleString("pt-BR")}</p>
                  <p className="text-xs text-muted-foreground">{Number(a.ctr).toFixed(1)}% CTR</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
