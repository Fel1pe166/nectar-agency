import { createFileRoute, Link } from "@tanstack/react-router";
import * as React from "react";
import { Check, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";
import { PLANS, type PlanDef } from "@/lib/plans";
import { PlanBadge } from "@/components/PlanBadge";
import { PaymentDialog } from "@/components/PaymentDialog";

export const Route = createFileRoute("/app/planos")({
  component: Planos,
});

function Planos() {
  const { profile } = useAuth();
  const [selected, setSelected] = React.useState<PlanDef | null>(null);
  const [open, setOpen] = React.useState(false);
  return (
    <div className="space-y-10">
      <div className="text-center">
        <Crown className="mx-auto h-9 w-9 text-primary" />
        <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">Planos VIP</h1>
        <p className="mx-auto mt-2 max-w-xl text-muted-foreground">
          Mais visualizações, destaque nos anúncios e prioridade máxima na plataforma.
        </p>
        <div className="mt-4 inline-flex items-center gap-2 text-sm">
          <span className="text-muted-foreground">Plano atual:</span>
          <PlanBadge plan={profile?.plan} size="md" />
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-5 md:grid-cols-2">
        {PLANS.map((p) => {
          const current = profile?.plan === p.name;
          return (
            <div
              key={p.name}
              className={cn(
                "relative flex flex-col rounded-2xl border bg-card p-6 card-hover",
                p.popular && "border-primary glow-yellow",
              )}
            >
              {p.popular && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground shadow-glow">
                  Mais Popular
                </Badge>
              )}
              <PlanBadge plan={p.name} />
              <p className="mt-4 text-sm font-semibold uppercase tracking-wider text-muted-foreground">{p.label}</p>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-4xl font-extrabold">R${p.price.toFixed(2).replace(".", ",")}</span>
                {p.price > 0 && <span className="text-xs text-muted-foreground">/mês</span>}
              </div>
              <p className="mt-2 text-xs font-medium text-primary">
                {p.adLimit === -1 ? "Anúncios ilimitados" : `${p.adLimit} anúncio${p.adLimit > 1 ? "s" : ""}`}
              </p>
              <ul className="my-5 space-y-2 text-sm">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <Button
                variant={p.popular ? "glow" : current ? "outline" : "dark"}
                className="mt-auto w-full"
                disabled={current || p.price === 0}
                onClick={() => {
                  if (current || p.price === 0) return;
                  setSelected(p);
                  setOpen(true);
                }}
              >
                {current ? "Plano atual" : p.cta}
              </Button>
            </div>
          );
        })}
      </div>

      <p className="text-center text-xs text-muted-foreground">
        <Link to="/app" className="underline">← Voltar ao dashboard</Link>
      </p>

      <PaymentDialog plan={selected} open={open} onOpenChange={setOpen} />
    </div>
  );
}
