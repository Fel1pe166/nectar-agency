import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import * as React from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ArrowLeft, ShieldCheck, CheckCircle2, XCircle, Search, FileText, Clock, DollarSign } from "lucide-react";
import { toast } from "sonner";
import { PLANS, getPlan } from "@/lib/plans";
import { PlanBadge } from "@/components/PlanBadge";
import { useCountUp } from "@/hooks/use-count-up";

export const Route = createFileRoute("/admin/pagaments")({
  head: () => ({ meta: [{ title: "Pagamentos · Admin Néctar" }, { name: "robots", content: "noindex" }] }),
  component: AdminPayments,
});

const UNLOCK_KEY = "nectar.admin.unlocked";

type Payment = {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  plan: string;
  receipt_url: string | null;
  status: "pending" | "approved" | "rejected" | string;
  created_at: string;
};

function AdminPayments() {
  const navigate = useNavigate();
  const [authorized, setAuthorized] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [items, setItems] = React.useState<Payment[]>([]);
  const [filter, setFilter] = React.useState<"all" | "pending" | "approved" | "rejected">("all");
  const [query, setQuery] = React.useState("");

  React.useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem(UNLOCK_KEY) !== "1") {
      navigate({ to: "/admin-secret" });
      return;
    }
    setAuthorized(true);
  }, [navigate]);

  const load = React.useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("payments")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(300);
    if (error) toast.error(error.message);
    setItems((data as Payment[]) ?? []);
    setLoading(false);
  }, []);

  React.useEffect(() => {
    if (authorized) void load();
  }, [authorized, load]);

  if (!authorized) return null;

  const total = items.length;
  const pending = items.filter((p) => p.status === "pending").length;
  const approved = items.filter((p) => p.status === "approved").length;
  const revenue = items
    .filter((p) => p.status === "approved")
    .reduce((s, p) => s + (getPlan(p.plan).price ?? 0), 0);

  const approve = async (p: Payment) => {
    try {
      const { error: e1 } = await supabase
        .from("payments")
        .update({ status: "approved" })
        .eq("id", p.id);
      if (e1) throw e1;
      const { error: e2 } = await supabase
        .from("profiles")
        .update({ plan: p.plan })
        .eq("id", p.user_id);
      if (e2) throw e2;
      toast.success(`Plano ${p.plan} ativado para ${p.full_name}`);
      setItems((arr) => arr.map((x) => (x.id === p.id ? { ...x, status: "approved" } : x)));
    } catch (err: any) {
      toast.error(err?.message ?? "Erro ao aprovar");
    }
  };

  const reject = async (p: Payment) => {
    const { error } = await supabase
      .from("payments")
      .update({ status: "rejected" })
      .eq("id", p.id);
    if (error) return toast.error(error.message);
    toast.success("Pagamento recusado");
    setItems((arr) => arr.map((x) => (x.id === p.id ? { ...x, status: "rejected" } : x)));
  };

  const filtered = items.filter((p) => {
    if (filter !== "all" && p.status !== filter) return false;
    if (!query) return true;
    const q = query.toLowerCase();
    return (
      p.full_name.toLowerCase().includes(q) ||
      p.email.toLowerCase().includes(q) ||
      p.plan.toLowerCase().includes(q)
    );
  });

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="sticky top-0 z-30 border-b bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
          <Link to="/admin" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Painel
          </Link>
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-primary glow-yellow">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <div className="leading-tight">
            <div className="text-base font-extrabold">Pagamentos</div>
            <div className="text-xs text-muted-foreground">Aprovação manual de comprovantes PIX</div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6 lg:py-8">
        <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <StatBox icon={FileText} label="Total" value={total} />
          <StatBox icon={Clock} label="Pendentes" value={pending} accent />
          <StatBox icon={CheckCircle2} label="Aprovados" value={approved} />
          <StatBox icon={DollarSign} label="Arrecadado" value={Math.round(revenue)} suffix=" R$" accent />
        </section>

        <Card className="p-4 sm:p-5">
          <div className="flex flex-wrap items-center gap-2">
            {(["all", "pending", "approved", "rejected"] as const).map((f) => (
              <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} onClick={() => setFilter(f)}>
                {f === "all" ? "Todos" : f === "pending" ? "Pendentes" : f === "approved" ? "Aprovados" : "Recusados"}
              </Button>
            ))}
            <div className="relative ml-auto w-full max-w-xs">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar..." className="pl-9" />
            </div>
          </div>

          <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {loading ? (
              <p className="col-span-full py-10 text-center text-sm text-muted-foreground">Carregando...</p>
            ) : filtered.length === 0 ? (
              <p className="col-span-full py-10 text-center text-sm text-muted-foreground">Nenhum pagamento</p>
            ) : (
              filtered.map((p) => (
                <Card key={p.id} className="overflow-hidden">
                  {p.receipt_url && (
                    <a href={p.receipt_url} target="_blank" rel="noopener noreferrer" className="block">
                      <div className="aspect-video w-full overflow-hidden bg-muted">
                        {/\.(png|jpe?g|webp|gif)$/i.test(p.receipt_url) ? (
                          <img src={p.receipt_url} alt="Comprovante" className="h-full w-full object-cover" />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                            <FileText className="h-10 w-10" />
                          </div>
                        )}
                      </div>
                    </a>
                  )}
                  <div className="space-y-3 p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="truncate font-semibold">{p.full_name}</div>
                        <div className="truncate text-xs text-muted-foreground">{p.email}</div>
                      </div>
                      <StatusBadge status={p.status} />
                    </div>
                    <div className="flex items-center justify-between">
                      <PlanBadge plan={p.plan} size="sm" />
                      <span className="text-sm font-bold">
                        R${(getPlan(p.plan).price ?? 0).toFixed(2).replace(".", ",")}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                      <span className="font-mono">{p.user_id.slice(0, 8)}</span>
                      <span>{new Date(p.created_at).toLocaleString("pt-BR")}</span>
                    </div>
                    {p.status === "pending" && (
                      <div className="flex gap-2 pt-1">
                        <Button size="sm" className="flex-1 bg-emerald-600 text-white hover:bg-emerald-700" onClick={() => approve(p)}>
                          <CheckCircle2 className="mr-1 h-4 w-4" /> Aprovar
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1" onClick={() => reject(p)}>
                          <XCircle className="mr-1 h-4 w-4" /> Recusar
                        </Button>
                      </div>
                    )}
                  </div>
                </Card>
              ))
            )}
          </div>
        </Card>

        {/* Logística */}
        <Card className="p-6">
          <h2 className="text-lg font-extrabold">Logística da Plataforma</h2>
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl border bg-muted/30 p-4">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Por que a Néctar foi criada?</div>
              <p className="mt-1 text-sm">Para todo mundo divulgar livremente.</p>
            </div>
            <div className="rounded-xl border bg-muted/30 p-4">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Planos disponíveis</div>
              <p className="mt-1 text-sm">{PLANS.length} níveis ativos — Free até Avançado.</p>
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
}

function StatBox({
  icon: Icon, label, value, suffix, accent,
}: { icon: typeof FileText; label: string; value: number; suffix?: string; accent?: boolean }) {
  const v = useCountUp(value, 800);
  return (
    <Card className={`p-4 ${accent ? "border-primary/40 glow-yellow" : ""}`}>
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
        <span className={`grid h-8 w-8 place-items-center rounded-lg ${accent ? "bg-secondary text-primary" : "bg-muted"}`}>
          <Icon className="h-4 w-4" />
        </span>
      </div>
      <div className="mt-2 text-2xl font-extrabold">{v.toLocaleString("pt-BR")}{suffix}</div>
    </Card>
  );
}

function StatusBadge({ status }: { status: string }) {
  if (status === "approved")
    return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100"><CheckCircle2 className="mr-1 h-3 w-3" />Aprovado</Badge>;
  if (status === "rejected")
    return <Badge variant="destructive"><XCircle className="mr-1 h-3 w-3" />Recusado</Badge>;
  return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100"><Clock className="mr-1 h-3 w-3" />Pendente</Badge>;
}
