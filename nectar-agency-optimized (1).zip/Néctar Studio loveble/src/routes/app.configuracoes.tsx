import { createFileRoute } from "@tanstack/react-router";
import { Bell, Globe, Lock, Moon } from "lucide-react";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/app/configuracoes")({
  component: Configuracoes,
});

const opts = [
  { icon: Bell, title: "Notificações por email", desc: "Receber alertas sobre desempenho dos anúncios." },
  { icon: Moon, title: "Modo escuro", desc: "Reduz a intensidade da luz para sessões longas." },
  { icon: Globe, title: "Conta pública", desc: "Permitir que outros usuários vejam seu perfil." },
  { icon: Lock, title: "Autenticação em 2 etapas", desc: "Camada extra de segurança no login." },
];

function Configuracoes() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
        <p className="text-sm text-muted-foreground">Personalize a sua experiência na Néctar Agency.</p>
      </div>
      <div className="rounded-2xl border bg-card divide-y">
        {opts.map((o) => (
          <div key={o.title} className="flex items-center gap-4 p-5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15">
              <o.icon className="h-5 w-5" />
            </span>
            <div className="flex-1">
              <p className="font-medium">{o.title}</p>
              <p className="text-sm text-muted-foreground">{o.desc}</p>
            </div>
            <Switch />
          </div>
        ))}
      </div>
    </div>
  );
}
