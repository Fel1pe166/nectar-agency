import { createFileRoute, Outlet, Link, useNavigate, useRouterState } from "@tanstack/react-router";
import * as React from "react";
import {
  Home, FolderKanban, Crown, BarChart3, Megaphone, User, Settings, LogOut, Menu, Bell, Search,
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider,
  SidebarTrigger, SidebarFooter,
} from "@/components/ui/sidebar";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/lib/auth";
import { PlanBadge } from "@/components/PlanBadge";
import { toast } from "sonner";

export const Route = createFileRoute("/app")({
  component: AppLayout,
});

const items: { title: string; url: string; icon: typeof Home; exact?: boolean }[] = [
  { title: "Início", url: "/app", icon: Home, exact: true },
  { title: "Categorias", url: "/app/categorias", icon: FolderKanban },
  { title: "Ver Planos", url: "/app/planos", icon: Crown },
  { title: "Estatísticas", url: "/app/estatisticas", icon: BarChart3 },
  { title: "Meus Anúncios", url: "/app/anuncios", icon: Megaphone },
  { title: "Sua Conta", url: "/app/conta", icon: User },
  { title: "Configurações", url: "/app/configuracoes", icon: Settings },
];

function AppLayout() {
  const { user, profile, loading, logout } = useAuth();
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });

  React.useEffect(() => {
    if (!loading && !user) navigate({ to: "/login" });
  }, [user, loading, navigate]);

  if (loading || !user) return null;

  const displayName = profile?.username || user.email?.split("@")[0] || "Usuário";
  const initial = displayName.slice(0, 1).toUpperCase();

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-muted/20">
        <Sidebar collapsible="offcanvas">
          <SidebarHeader className="border-b">
            <div className="px-2 py-1.5"><Logo /></div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>Plataforma</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {items.map((it) => {
                    const active = it.exact ? path === it.url : path === it.url || path.startsWith(it.url + "/");
                    return (
                      <SidebarMenuItem key={it.url}>
                        <SidebarMenuButton asChild isActive={active}>
                          <Link to={it.url as "/app"} className="flex items-center gap-2">
                            <it.icon className="h-4 w-4" />
                            <span>{it.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
          <SidebarFooter className="border-t">
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={async () => {
                    await logout();
                    toast.success("Sessão encerrada");
                    navigate({ to: "/" });
                  }}
                >
                  <LogOut className="h-4 w-4" /> <span>Sair</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarFooter>
        </Sidebar>

        <div className="flex min-h-screen flex-1 flex-col">
          <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur-xl sm:px-6">
            <SidebarTrigger className="rounded-xl border bg-background hover:bg-primary hover:text-primary-foreground transition-colors shadow-sm">
              <Menu className="h-5 w-5" />
            </SidebarTrigger>
            <div className="relative ml-2 hidden flex-1 max-w-md md:block">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Buscar anúncios, categorias..." className="pl-9" />
            </div>
            <div className="ml-auto flex items-center gap-3">
              <PlanBadge plan={profile?.plan} className="hidden sm:inline-flex" />
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-primary" />
              </Button>
              <Avatar className="h-9 w-9 border">
                {profile?.avatar_url && <AvatarImage src={profile.avatar_url} />}
                <AvatarFallback className="bg-secondary text-primary font-bold">
                  {initial}
                </AvatarFallback>
              </Avatar>
            </div>
          </header>
          <main className="flex-1 p-4 sm:p-6 lg:p-8">
            <div className="animate-fade-in-up">
              <Outlet />
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
