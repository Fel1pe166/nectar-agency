import { createFileRoute, Link } from "@tanstack/react-router";
import * as React from "react";
import { Search, Plus, Eye, MousePointerClick, Sparkles, Trash2, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { PlanBadge } from "@/components/PlanBadge";

export const Route = createFileRoute("/app/anuncios")({
  component: Anuncios,
});

const cats = ["Todas", "WhatsApp", "Discord", "Instagram", "TikTok", "Produtos", "Serviços"];

function Anuncios() {
  const { user, profile, refreshProfile } = useAuth();
  const [q, setQ] = React.useState("");
  const [cat, setCat] = React.useState("Todas");
  const [ads, setAds] = React.useState<Tables<"ads">[]>([]);
  const [loading, setLoading] = React.useState(true);

  const load = React.useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("ads")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    setAds(data ?? []);
    setLoading(false);
  }, [user]);

  React.useEffect(() => { void load(); }, [load]);

  const filtered = ads.filter(
    (a) =>
      (cat === "Todas" || a.category === cat) &&
      (a.title.toLowerCase().includes(q.toLowerCase()) ||
        a.description.toLowerCase().includes(q.toLowerCase())),
  );

  const handleDelete = async (id: string) => {
    if (!confirm("Deletar este anúncio?")) return;
    const { error } = await supabase.from("ads").delete().eq("id", id);
    if (error) return toast.error(error.message);
    if (user) {
      await supabase.from("profiles").update({ ads_used: Math.max(0, (profile?.ads_used ?? 1) - 1) }).eq("id", user.id);
      await refreshProfile();
    }
    toast.success("Anúncio deletado");
    void load();
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Meus Anúncios</h1>
          <p className="mt-1 text-muted-foreground">Gerencie todos os seus anúncios publicados.</p>
        </div>
        <Button asChild variant="glow"><Link to="/app/criar"><Plus className="mr-1 h-4 w-4" /> Novo anúncio</Link></Button>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar anúncios..." className="pl-9" />
        </div>
        <Select value={cat} onValueChange={setCat}>
          <SelectTrigger className="sm:w-56"><SelectValue /></SelectTrigger>
          <SelectContent>
            {cats.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin" /></div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border bg-card p-12 text-center text-muted-foreground">
          {ads.length === 0 ? (
            <>Você ainda não criou anúncios. <Link to="/app/criar" className="text-primary underline">Criar agora</Link></>
          ) : "Nenhum anúncio encontrado com esses filtros."}
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((a) => (
            <article key={a.id} className={cn(
              "group relative flex flex-col overflow-hidden rounded-2xl border bg-card card-hover",
              a.vip ? "border-primary/40 glow-yellow" : "border-border",
            )}>
              {a.vip && (
                <div className="absolute right-3 top-3 z-10">
                  <Badge className="gap-1 bg-primary text-primary-foreground shadow-glow">
                    <Sparkles className="h-3 w-3" /> VIP
                  </Badge>
                </div>
              )}
              <div className="aspect-[16/10] overflow-hidden bg-muted">
                {a.image_url ? (
                  <img src={a.image_url} alt={a.title} loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                ) : (
                  <div className="grid h-full w-full place-items-center text-muted-foreground">Sem imagem</div>
                )}
              </div>
              <div className="flex flex-1 flex-col gap-3 p-5">
                <div className="flex items-center justify-between">
                  <Badge variant="secondary" className="rounded-full text-xs">{a.category}</Badge>
                  <PlanBadge plan={profile?.plan} size="sm" />
                </div>
                <h3 className="text-lg font-semibold leading-snug">{a.title}</h3>
                <p className="line-clamp-2 text-sm text-muted-foreground">{a.description}</p>
                <div className="mt-1 flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1"><Eye className="h-3.5 w-3.5" /> {a.views.toLocaleString("pt-BR")}</span>
                  <span className="inline-flex items-center gap-1"><MousePointerClick className="h-3.5 w-3.5" /> {Number(a.ctr).toFixed(1)}% CTR</span>
                </div>
                <div className="flex gap-2 mt-2">
                  {a.link_url && (
                    <Button asChild variant={a.vip ? "glow" : "dark"} className="flex-1" size="sm">
                      <a href={a.link_url} target="_blank" rel="noopener noreferrer">Visitar</a>
                    </Button>
                  )}
                  <Button variant="outline" size="icon" onClick={() => handleDelete(a.id)} aria-label="Deletar">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
