import { createFileRoute, useNavigate } from "@tanstack/react-router";
import * as React from "react";
import { ImagePlus, Sparkles, AlertCircle, Eye, MousePointerClick, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { getPlan, canCreateAd, planLimitText } from "@/lib/plans";
import { PlanBadge } from "@/components/PlanBadge";

export const Route = createFileRoute("/app/criar")({
  component: CriarAnuncio,
});

const cats = ["WhatsApp", "Discord", "Instagram", "TikTok", "Produtos", "Serviços"];

function CriarAnuncio() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const plan = getPlan(profile?.plan);
  const used = profile?.ads_used ?? 0;
  const allowed = canCreateAd(plan, used);
  const isVip = plan.name !== "Free";

  const [form, setForm] = React.useState({
    title: "", description: "", link: "", image: "", category: "",
  });
  const [submitting, setSubmitting] = React.useState(false);

  const set = (k: keyof typeof form) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!allowed) return toast.error(`Limite do plano ${plan.label} atingido (${planLimitText(plan, used)})`);
    if (!form.title || !form.description || !form.category) {
      return toast.error("Preencha todos os campos obrigatórios");
    }
    setSubmitting(true);
    try {
      const { error } = await supabase.from("ads").insert({
        user_id: user.id,
        title: form.title,
        description: form.description,
        category: form.category,
        image_url: form.image || null,
        link_url: form.link || null,
        vip: isVip,
      });
      if (error) throw error;
      // Increment ads_used
      await supabase.from("profiles").update({ ads_used: used + 1 }).eq("id", user.id);
      await refreshProfile();
      toast.success("Anúncio publicado com sucesso!");
      navigate({ to: "/app/anuncios" });
    } catch (e: any) {
      toast.error(e?.message ?? "Erro ao publicar");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Criar anúncio</h1>
          <p className="mt-1 text-muted-foreground">Capriche nos detalhes — anúncios bem feitos convertem mais.</p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <PlanBadge plan={profile?.plan} size="lg" />
          <p className="text-xs text-muted-foreground">{planLimitText(plan, used)} anúncios usados</p>
        </div>
      </div>

      {!allowed && (
        <div className="flex items-start gap-3 rounded-2xl border border-primary/40 bg-primary/10 p-4 glow-yellow">
          <AlertCircle className="mt-0.5 h-5 w-5 text-foreground" />
          <div>
            <p className="font-semibold">Limite do plano atingido</p>
            <p className="text-sm text-muted-foreground">
              Você usou {planLimitText(plan, used)} anúncios. Faça upgrade para criar mais.
            </p>
          </div>
        </div>
      )}

      <div className="grid gap-8 lg:grid-cols-5">
        <form onSubmit={submit} className="space-y-5 rounded-2xl border bg-card p-6 lg:col-span-3">
          <div className="space-y-1.5">
            <Label htmlFor="title">Título do anúncio *</Label>
            <Input id="title" value={form.title} onChange={(e) => set("title")(e.target.value)} placeholder="Ex.: Comunidade Premium WhatsApp" maxLength={120} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="desc">Descrição *</Label>
            <Textarea id="desc" rows={4} value={form.description} onChange={(e) => set("description")(e.target.value)} placeholder="Conte o que torna seu anúncio especial..." maxLength={500} />
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="link">Link de destino</Label>
              <Input id="link" type="url" value={form.link} onChange={(e) => set("link")(e.target.value)} placeholder="https://" />
            </div>
            <div className="space-y-1.5">
              <Label>Categoria *</Label>
              <Select value={form.category} onValueChange={set("category")}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  {cats.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="img">URL da imagem</Label>
            <div className="flex gap-2">
              <Input id="img" value={form.image} onChange={(e) => set("image")(e.target.value)} placeholder="https://..." />
              <Button type="button" variant="outline" size="icon"><ImagePlus className="h-4 w-4" /></Button>
            </div>
            <p className="text-xs text-muted-foreground">Recomendado: 1200×750, JPG ou PNG.</p>
          </div>
          <Button type="submit" variant="glow" size="lg" className="w-full" disabled={submitting || !allowed}>
            {submitting ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Sparkles className="mr-1 h-4 w-4" />}
            Publicar Anúncio
          </Button>
        </form>

        <div className="lg:col-span-2">
          <p className="mb-3 text-sm font-medium text-muted-foreground">Pré-visualização</p>
          <article className={cn("flex flex-col overflow-hidden rounded-2xl border bg-card", isVip && "border-primary/40 glow-yellow")}>
            <div className="aspect-[16/10] overflow-hidden bg-muted">
              {form.image ? (
                <img src={form.image} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                  <ImagePlus className="h-10 w-10" />
                </div>
              )}
            </div>
            <div className="space-y-3 p-5">
              {form.category && <Badge variant="secondary" className="rounded-full">{form.category}</Badge>}
              <h3 className="text-lg font-semibold">{form.title || "Título do seu anúncio"}</h3>
              <p className="line-clamp-2 text-sm text-muted-foreground">
                {form.description || "A descrição aparecerá aqui em tempo real."}
              </p>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1"><Eye className="h-3.5 w-3.5" /> 0</span>
                <span className="inline-flex items-center gap-1"><MousePointerClick className="h-3.5 w-3.5" /> 0% CTR</span>
              </div>
              <div className="flex items-center justify-between">
                <PlanBadge plan={profile?.plan} size="sm" />
                <Button variant={isVip ? "glow" : "dark"} size="sm">Ver anúncio</Button>
              </div>
            </div>
          </article>
        </div>
      </div>
    </div>
  );
}
