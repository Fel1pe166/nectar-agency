import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BarChart3,
  Sparkles,
  Zap,
  ShieldCheck,
  Rocket,
  MessageCircle,
  Hash,
  Instagram,
  Music2,
  ShoppingBag,
  Briefcase,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { AdCard } from "@/components/AdCard";
import { ads, plans } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  component: Landing,
});

const categoryIcons = {
  WhatsApp: MessageCircle,
  Discord: Hash,
  Instagram: Instagram,
  TikTok: Music2,
  Produtos: ShoppingBag,
  Serviços: Briefcase,
} as const;

const cats = [
  { name: "WhatsApp", count: 248 },
  { name: "Discord", count: 184 },
  { name: "Instagram", count: 312 },
  { name: "TikTok", count: 167 },
  { name: "Produtos", count: 421 },
  { name: "Serviços", count: 198 },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      {/* Hero */}
      <section className="relative overflow-hidden bg-hero">
        <div className="mx-auto max-w-7xl px-4 pb-24 pt-16 sm:px-6 sm:pt-24 lg:pt-32">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="animate-fade-in-up space-y-7">
              <Badge className="gap-1 rounded-full border border-primary/30 bg-primary/10 px-3 py-1.5 text-xs font-medium text-foreground hover:bg-primary/15">
                <Sparkles className="h-3.5 w-3.5 text-primary" />
                Plataforma premium de divulgação
              </Badge>
              <h1 className="text-balance text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
                Cresça no digital com{" "}
                <span className="relative whitespace-nowrap">
                  <span className="bg-gradient-primary bg-clip-text text-transparent">anúncios premium</span>
                  <span className="absolute -bottom-1 left-0 h-2 w-full rounded-full bg-primary/40 blur-sm" />
                </span>
              </h1>
              <p className="max-w-xl text-lg text-muted-foreground">
                Néctar Agency conecta marcas, criadores e comunidades à audiência certa — com sistema VIP, estatísticas em tempo real e uma interface feita para converter.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button asChild size="xl" variant="glow">
                  <Link to="/login">
                    Começar agora <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild size="xl" variant="outline">
                  <a href="#anuncios">Ver anúncios</a>
                </Button>
              </div>
              <div className="flex items-center gap-6 pt-2 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-primary" /> Sem cartão</span>
                <span className="inline-flex items-center gap-2"><Zap className="h-4 w-4 text-primary" /> Setup em 1 min</span>
              </div>
            </div>

            <div className="relative animate-fade-in-up [animation-delay:200ms]">
              <div className="absolute -inset-6 rounded-[2rem] bg-gradient-primary opacity-20 blur-3xl" />
              <div className="relative rounded-2xl border bg-card p-5 shadow-elegant animate-float">
                <div className="mb-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-destructive" />
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    <div className="h-2 w-2 rounded-full bg-emerald-500" />
                  </div>
                  <Badge variant="secondary" className="text-xs">Dashboard</Badge>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: "Visualizações", value: "128.4k", trend: "+18%" },
                    { label: "Anúncios", value: "24", trend: "+3" },
                    { label: "CTR médio", value: "7.8%", trend: "+0.6" },
                  ].map((s) => (
                    <div key={s.label} className="rounded-xl border bg-background p-3">
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.label}</p>
                      <p className="mt-1 text-lg font-bold">{s.value}</p>
                      <p className="text-[10px] font-medium text-emerald-600">{s.trend}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-4 rounded-xl border bg-background p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <p className="text-sm font-semibold">Performance</p>
                    <BarChart3 className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex h-24 items-end gap-1.5">
                    {[40, 65, 50, 80, 60, 90, 75, 95, 70, 85, 100, 88].map((h, i) => (
                      <div
                        key={i}
                        className="flex-1 rounded-t bg-gradient-to-t from-primary/40 to-primary"
                        style={{ height: `${h}%` }}
                      />
                    ))}
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-3 rounded-xl border bg-background p-3">
                  <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary text-primary-foreground">
                    <Sparkles className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold">Plano Premium ativo</p>
                    <p className="text-xs text-muted-foreground">Glow VIP em todos seus anúncios</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categorias */}
      <section id="categorias" className="border-t bg-background py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mb-10 flex items-end justify-between gap-4">
            <div>
              <Badge variant="secondary" className="mb-3 rounded-full">Categorias</Badge>
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Explore por canal</h2>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {cats.map((c) => {
              const Icon = categoryIcons[c.name as keyof typeof categoryIcons];
              return (
                <button
                  key={c.name}
                  className="group flex flex-col items-start gap-3 rounded-2xl border bg-card p-5 text-left card-hover hover:border-primary/40"
                >
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-secondary text-primary transition-transform group-hover:scale-110">
                    <Icon className="h-5 w-5" />
                  </span>
                  <div>
                    <p className="font-semibold">{c.name}</p>
                    <p className="text-xs text-muted-foreground">{c.count} anúncios</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Anúncios em destaque */}
      <section id="anuncios" className="bg-muted/30 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
            <div>
              <Badge variant="secondary" className="mb-3 rounded-full">
                <Sparkles className="mr-1 h-3 w-3 text-primary" /> Em alta
              </Badge>
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Anúncios em Destaque</h2>
              <p className="mt-2 text-muted-foreground">Os melhores criadores e marcas da plataforma.</p>
            </div>
            <Button asChild variant="dark">
              <Link to="/app/anuncios">Ver todos <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {ads.map((a) => <AdCard key={a.id} ad={a} />)}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mx-auto mb-12 max-w-2xl text-center">
            <Badge variant="secondary" className="mb-3 rounded-full">Diferenciais</Badge>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              Tudo o que você precisa para crescer
            </h2>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: Sparkles, title: "Sistema VIP premium", desc: "Destaque seus anúncios com badge VIP e glow amarelo exclusivo." },
              { icon: BarChart3, title: "Estatísticas em tempo real", desc: "Acompanhe visualizações, CTR e performance ao vivo." },
              { icon: Rocket, title: "Alta conversão", desc: "Layouts otimizados para transformar visitas em cliques." },
              { icon: ShieldCheck, title: "Plataforma segura", desc: "Infraestrutura confiável para sua marca crescer com tranquilidade." },
              { icon: Zap, title: "Setup instantâneo", desc: "Crie seu primeiro anúncio em menos de um minuto." },
              { icon: Hash, title: "Multi-canal", desc: "WhatsApp, Discord, Instagram, TikTok e muito mais." },
            ].map((f) => (
              <div key={f.title} className="group rounded-2xl border bg-card p-6 card-hover hover:border-primary/40">
                <div className="mb-4 inline-grid h-11 w-11 place-items-center rounded-xl bg-primary/15 text-foreground transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="mb-1.5 font-semibold">{f.title}</h3>
                <p className="text-sm text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Planos */}
      <section id="planos" className="border-t bg-muted/30 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mx-auto mb-12 max-w-2xl text-center">
            <Badge variant="secondary" className="mb-3 rounded-full">Planos VIP</Badge>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Escolha seu plano</h2>
            <p className="mt-2 text-muted-foreground">Mais visualizações, mais destaque, mais resultados.</p>
          </div>
          <div className="grid gap-6 lg:grid-cols-3">
            {plans.map((p) => (
              <div
                key={p.name}
                className={cn(
                  "relative flex flex-col rounded-2xl border bg-card p-7 card-hover",
                  p.popular && "border-primary glow-yellow",
                )}
              >
                {p.popular && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground shadow-glow">
                    Mais Popular
                  </Badge>
                )}
                <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">{p.name}</p>
                <div className="mt-3 flex items-baseline gap-1">
                  <span className="text-4xl font-extrabold">R${p.price}</span>
                  <span className="text-sm text-muted-foreground">/mês</span>
                </div>
                <ul className="my-6 space-y-2.5 text-sm">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <Button asChild variant={p.popular ? "glow" : "dark"} className="mt-auto w-full" size="lg">
                  <Link to="/app/planos">{p.cta}</Link>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <div className="relative overflow-hidden rounded-3xl bg-secondary p-10 text-secondary-foreground shadow-elegant sm:p-16">
            <div className="absolute -right-10 -top-10 h-64 w-64 rounded-full bg-primary/30 blur-3xl" />
            <div className="absolute -left-10 -bottom-10 h-64 w-64 rounded-full bg-primary/20 blur-3xl" />
            <div className="relative flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
              <div className="max-w-xl">
                <h3 className="text-3xl font-bold">Pronto para escalar sua presença digital?</h3>
                <p className="mt-2 text-secondary-foreground/70">Comece grátis e ative o VIP quando quiser.</p>
              </div>
              <Button asChild size="xl" variant="glow">
                <Link to="/login">
                  Criar conta <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
