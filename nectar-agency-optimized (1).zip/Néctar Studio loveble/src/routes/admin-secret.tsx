import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import * as React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Lock, ShieldCheck, AlertTriangle, ArrowLeft, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin-secret")({
  head: () => ({ meta: [{ title: "Acesso restrito" }, { name: "robots", content: "noindex" }] }),
  component: AdminSecretPage,
});

const QUESTIONS: { q: string; a: string; placeholder?: string; type?: string }[] = [
  { q: "Qual é a missão original da Néctar?", a: "divulgação livre", placeholder: "Resposta..." },
  { q: "Complete a frase: Néctar conecta _______ e divulgação.", a: "crescimento", placeholder: "Uma palavra" },
  { q: "Qual é o nome oficial da plataforma?", a: "néctar agency", placeholder: "Nome completo" },
  { q: "Digite a chave administrativa.", a: "NECTAR-ADMIN-2026", placeholder: "Chave", type: "password" },
];

const LOCKOUT_KEY = "nectar.admin.lockUntil";
const UNLOCK_KEY = "nectar.admin.unlocked";

function normalize(s: string) {
  return s
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function AdminSecretPage() {
  const navigate = useNavigate();
  const [step, setStep] = React.useState(0);
  const [value, setValue] = React.useState("");
  const [shake, setShake] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [lockUntil, setLockUntil] = React.useState<number>(0);
  const [now, setNow] = React.useState(Date.now());
  const [verifying, setVerifying] = React.useState(false);

  React.useEffect(() => {
    const raw = typeof window !== "undefined" ? localStorage.getItem(LOCKOUT_KEY) : null;
    if (raw) setLockUntil(parseInt(raw, 10) || 0);
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, []);

  const locked = lockUntil > now;
  const remaining = Math.max(0, Math.ceil((lockUntil - now) / 1000));
  const current = QUESTIONS[step];

  const fail = () => {
    setShake(true);
    setError("Resposta incorreta. Acesso negado.");
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      navigator.vibrate?.([80, 40, 80, 40, 200]);
    }
    const until = Date.now() + 30_000;
    localStorage.setItem(LOCKOUT_KEY, String(until));
    setLockUntil(until);
    setStep(0);
    setValue("");
    setTimeout(() => setShake(false), 700);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (locked || verifying) return;
    setError(null);
    const correct =
      step === 3
        ? value.trim() === current.a
        : normalize(value) === normalize(current.a);

    if (!correct) {
      fail();
      return;
    }

    if (step < QUESTIONS.length - 1) {
      setStep(step + 1);
      setValue("");
      return;
    }

    setVerifying(true);
    // Promote current user to admin role (if signed in) so RLS allows admin actions
    try {
      await supabase.rpc("claim_admin", { secret_key: "NECTAR-ADMIN-2026" });
    } catch {
      // ignore — admin panel still unlocks via session flag
    }
    setTimeout(() => {
      sessionStorage.setItem(UNLOCK_KEY, "1");
      navigate({ to: "/admin" });
    }, 900);
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-background">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-32 top-1/4 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute -right-32 bottom-1/4 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
      </div>

      <div className="relative mx-auto flex min-h-screen max-w-lg flex-col items-center justify-center px-4 py-12">
        <Link
          to="/"
          className="absolute left-4 top-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Voltar
        </Link>

        <div className="mb-6 flex flex-col items-center gap-3 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-secondary text-primary shadow-elegant glow-yellow">
            <Lock className="h-6 w-6" />
          </span>
          <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">
            Área Restrita · Néctar
          </h1>
          <p className="max-w-sm text-sm text-muted-foreground">
            Autenticação de administrador. Responda às quatro perguntas de segurança para continuar.
          </p>
        </div>

        <Card
          className={`w-full border-2 bg-card/80 p-6 backdrop-blur-xl transition-all ${
            shake ? "animate-shake border-destructive" : "border-border/60"
          }`}
        >
          {locked ? (
            <div className="flex flex-col items-center gap-3 py-6 text-center">
              <span className="grid h-12 w-12 place-items-center rounded-full bg-destructive/10 text-destructive">
                <AlertTriangle className="h-6 w-6" />
              </span>
              <h2 className="text-lg font-bold text-destructive">Acesso temporariamente bloqueado</h2>
              <p className="text-sm text-muted-foreground">
                Aguarde <span className="font-mono font-bold text-foreground">{remaining}s</span> antes de tentar novamente.
              </p>
            </div>
          ) : verifying ? (
            <div className="flex flex-col items-center gap-3 py-6 text-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-sm font-medium">Verificando credenciais...</p>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Pergunta {step + 1} de {QUESTIONS.length}
                </span>
                <div className="flex gap-1">
                  {QUESTIONS.map((_, i) => (
                    <span
                      key={i}
                      className={`h-1.5 w-6 rounded-full transition-colors ${
                        i < step ? "bg-primary" : i === step ? "bg-primary/60" : "bg-muted"
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="mb-2 block text-base font-semibold leading-snug">
                  {current.q}
                </label>
                <Input
                  autoFocus
                  type={current.type ?? "text"}
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  placeholder={current.placeholder}
                  className="h-12 text-base"
                />
              </div>

              {error && (
                <div className="flex items-center gap-2 rounded-lg border border-destructive/40 bg-destructive/5 px-3 py-2 text-sm text-destructive">
                  <AlertTriangle className="h-4 w-4" /> {error}
                </div>
              )}

              <Button type="submit" className="h-12 w-full text-base font-semibold" disabled={!value.trim()}>
                <ShieldCheck className="mr-2 h-5 w-5" />
                {step === QUESTIONS.length - 1 ? "Validar acesso" : "Continuar"}
              </Button>
            </form>
          )}
        </Card>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          🔒 Acesso monitorado. Tentativas inválidas são registradas.
        </p>
      </div>
    </div>
  );
}
