import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import * as React from "react";
import {
  Eye, EyeOff, ArrowRight, Sparkles, BarChart3, Rocket, ShieldCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Logo } from "@/components/Logo";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Entrar — Néctar Agency" },
      { name: "description", content: "Acesse sua conta Néctar Agency ou crie uma nova gratuitamente." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { login, signup, loginWithGoogle, user } = useAuth();
  const navigate = useNavigate();
  const [show, setShow] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    if (user) navigate({ to: "/app" });
  }, [user, navigate]);

  const onLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const email = String(fd.get("email") || "");
    const pw = String(fd.get("password") || "");
    if (!email || !pw) return toast.error("Preencha email e senha");
    setLoading(true);
    try {
      await login(email, pw);
      toast.success("Bem-vindo de volta!");
      navigate({ to: "/app" });
    } catch (e: any) {
      toast.error(e?.message ?? "Erro ao entrar");
    } finally { setLoading(false); }
  };

  const onSignup = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const name = String(fd.get("name") || "");
    const email = String(fd.get("email") || "");
    const pw = String(fd.get("password") || "");
    if (!name || !email || pw.length < 6) return toast.error("Preencha todos os campos (senha 6+)");
    setLoading(true);
    try {
      await signup(name, email, pw);
      toast.success("Conta criada! Verifique seu email se necessário.");
      navigate({ to: "/app" });
    } catch (e: any) {
      toast.error(e?.message ?? "Erro no cadastro");
    } finally { setLoading(false); }
  };

  const onGoogle = async () => {
    setLoading(true);
    try {
      await loginWithGoogle();
    } catch (e: any) {
      toast.error(e?.message ?? "Erro com Google");
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex flex-col p-6 sm:p-10">
        <Logo />
        <div className="m-auto w-full max-w-md animate-fade-in-up">
          <h1 className="text-3xl font-bold tracking-tight">Acesse sua conta</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Bem-vindo à Néctar Agency. Entre ou crie uma conta gratuita.
          </p>

          <Tabs defaultValue="login" className="mt-8">
            <TabsList className="grid w-full grid-cols-2 rounded-xl">
              <TabsTrigger value="login" className="rounded-lg">Acessar Conta</TabsTrigger>
              <TabsTrigger value="signup" className="rounded-lg">Criar Conta</TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="mt-6 space-y-4">
              <form onSubmit={onLogin} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" name="email" type="email" placeholder="voce@exemplo.com" autoComplete="email" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="password">Senha</Label>
                  <div className="relative">
                    <Input id="password" name="password" type={show ? "text" : "password"} placeholder="••••••••" autoComplete="current-password" className="pr-10" />
                    <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-2 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-md text-muted-foreground hover:bg-accent">
                      {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <Button type="submit" variant="glow" size="lg" className="w-full" disabled={loading}>
                  Entrar <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </form>
              <div className="flex items-center gap-3 py-1 text-xs text-muted-foreground">
                <div className="h-px flex-1 bg-border" /> ou <div className="h-px flex-1 bg-border" />
              </div>
              <Button type="button" variant="outline" size="lg" className="w-full" onClick={onGoogle} disabled={loading}>
                <GoogleIcon /> Continuar com Google
              </Button>
            </TabsContent>

            <TabsContent value="signup" className="mt-6 space-y-4">
              <form onSubmit={onSignup} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="name">Nome de usuário</Label>
                  <Input id="name" name="name" placeholder="Seu nome" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="email2">Email</Label>
                  <Input id="email2" name="email" type="email" placeholder="voce@exemplo.com" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="password2">Senha</Label>
                  <div className="relative">
                    <Input id="password2" name="password" type={show ? "text" : "password"} placeholder="Mínimo 6 caracteres" className="pr-10" />
                    <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-2 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-md text-muted-foreground hover:bg-accent">
                      {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <Button type="submit" variant="glow" size="lg" className="w-full" disabled={loading}>
                  Criar Conta
                </Button>
              </form>
              <Button type="button" variant="outline" size="lg" className="w-full" onClick={onGoogle} disabled={loading}>
                <GoogleIcon /> Cadastrar com Google
              </Button>
            </TabsContent>
          </Tabs>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            <Link to="/" className="hover:text-foreground">← Voltar para o site</Link>
          </p>
        </div>
      </div>

      <div className="relative hidden overflow-hidden bg-secondary text-secondary-foreground lg:block">
        <div className="absolute inset-0 bg-hero opacity-20" />
        <div className="absolute -right-20 -top-20 h-96 w-96 rounded-full bg-primary/40 blur-3xl" />
        <div className="absolute -bottom-24 -left-10 h-80 w-80 rounded-full bg-primary/20 blur-3xl" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <div className="inline-flex w-fit items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-xs backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-primary" /> Plataforma premium
          </div>
          <div className="space-y-6">
            <h2 className="text-balance text-4xl font-extrabold leading-tight">
              Cresça com <span className="text-primary">anúncios premium</span> e estatísticas em tempo real.
            </h2>
            <div className="grid gap-3 sm:grid-cols-2">
              {[
                { icon: BarChart3, t: "Estatísticas avançadas" },
                { icon: Rocket, t: "Alta conversão" },
                { icon: Sparkles, t: "Sistema VIP" },
                { icon: ShieldCheck, t: "100% seguro" },
              ].map((f) => (
                <div key={f.t} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-3 backdrop-blur">
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-primary text-primary-foreground">
                    <f.icon className="h-4 w-4" />
                  </span>
                  <span className="text-sm font-medium">{f.t}</span>
                </div>
              ))}
            </div>
          </div>
          <p className="text-xs text-secondary-foreground/60">© 2026 Néctar Agency</p>
        </div>
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4">
      <path fill="#EA4335" d="M12 10.2v3.9h5.5c-.2 1.4-1.6 4.1-5.5 4.1-3.3 0-6-2.7-6-6.2S8.7 5.8 12 5.8c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.8 3.3 14.6 2.4 12 2.4 6.7 2.4 2.4 6.7 2.4 12S6.7 21.6 12 21.6c6.9 0 11.4-4.8 11.4-11.6 0-.8-.1-1.4-.2-1.8H12z" />
    </svg>
  );
}
