import { createFileRoute } from "@tanstack/react-router";
import { MessageCircle, Hash, Instagram, Music2, ShoppingBag, Briefcase, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/app/categorias")({
  component: Categorias,
});

const cats = [
  { name: "WhatsApp", count: 248, icon: MessageCircle, desc: "Grupos, comunidades e listas." },
  { name: "Discord", count: 184, icon: Hash, desc: "Servidores e comunidades temáticas." },
  { name: "Instagram", count: 312, icon: Instagram, desc: "Perfis, reels e divulgação." },
  { name: "TikTok", count: 167, icon: Music2, desc: "Criadores e conteúdos virais." },
  { name: "Produtos", count: 421, icon: ShoppingBag, desc: "Lojas, ofertas e lançamentos." },
  { name: "Serviços", count: 198, icon: Briefcase, desc: "Profissionais e consultorias." },
];

function Categorias() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Categorias</h1>
        <p className="mt-1 text-muted-foreground">Explore anúncios por canal de divulgação.</p>
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {cats.map((c) => (
          <div key={c.name} className="group relative overflow-hidden rounded-2xl border bg-card p-6 card-hover hover:border-primary/40">
            <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full bg-primary/10 blur-2xl" />
            <div className="relative flex items-start justify-between">
              <span className="grid h-12 w-12 place-items-center rounded-xl bg-secondary text-primary transition-transform group-hover:-rotate-6">
                <c.icon className="h-6 w-6" />
              </span>
              <span className="text-xs font-medium text-muted-foreground">{c.count} anúncios</span>
            </div>
            <h3 className="relative mt-4 text-lg font-semibold">{c.name}</h3>
            <p className="relative mt-1 text-sm text-muted-foreground">{c.desc}</p>
            <Button variant="ghost" size="sm" className="relative mt-4 -ml-3">
              Ver anúncios <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
