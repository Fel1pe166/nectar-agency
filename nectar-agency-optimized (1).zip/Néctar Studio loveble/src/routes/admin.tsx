import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import * as React from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  ShieldCheck, Users, Megaphone, Crown, DollarSign, TrendingUp, Activity,
  LogOut, Search, Ban, CheckCircle2, ScrollText, ArrowLeft,
} from "lucide-react";
import { useCountUp } from "@/hooks/use-count-up";
import { PLANS } from "@/lib/plans";
import { toast } from "sonner";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Painel Admin · Néctar" }, { name: "robots", content: "noindex" }] }),
  component: AdminPanel,
});

const UNLOCK_KEY = "nectar.admin.unlocked";

type ProfileRow = {
  id: string;
  username: string;
  plan: string;
  ads_used: number;
  avatar_url: string | null;
  created_at: string;
  banned?: boolean;
};
type AdRow = {
  id: string;
  title: string;
  category: string;
  views: number;
  ctr: number;
  vip: boolean;
  user_id: string;
  created_at: string;
};

function StatCard({
  icon: Icon, label, value, suffix, accent,
}: { icon: typeof Users; label: string; value: number; suffix?: string; accent?: boolean }) {
  const v = useCountUp(value, 1000);
  return (
    <Card className={`relative overflow-hidden p-5 ${accent ? "border-primary/40 glow-yellow" : ""}`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
        <span className={`grid h-9 w-9 place-items-center rounded-xl ${accent ? "bg-secondary text-primary" : "bg-muted"}`}>
          <Icon className="h-4 w-4" />
        </span>
      </div>
      <div className="mt-3 text-3xl font-extrabold tracking-tight">
        {v.toLocaleString("pt-BR")}{suffix}
      </div>
    </Card>
  );
}

function AdminPanel() {
  const navigate = useNavigate();
  const [authorized, setAuthorized] = React.useState(false);
  const [profiles, setProfiles] = React.useState<ProfileRow[]>([]);
  const [ads, setAds] = React.useState<AdRow[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [tab, setTab] = React.useState<"users" | "ads" | "logs">("users");
  const [query, setQuery] = React.useState("");
  const [logs, setLogs] = React.useState<{ time: string; text: string; kind: "info" | "warn" | "ok" }[]>([
    { time: new Date().toLocaleTimeString(), text: "Painel admin inicializado", kind: "ok" },
  ]);

  React.useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem(UNLOCK_KEY) !== "1") {
      navigate({ to: "/admin-secret" });
      return;
    }
    setAuthorized(true);
  }, [navigate]);

  React.useEffect(() => {
    if (!authorized) return;
    (async () => {
      const [{ data: ps }, { data: as }] = await Promise.all([
        supabase.from("profiles").select("*").order("created_at", { ascending: false }).limit(200),
        supabase.from("ads").select("*").order("created_at", { ascending: false }).limit(200),
      ]);
      setProfiles((ps as ProfileRow[]) || []);
      setAds((as as AdRow[]) || []);
      setLoading(false);
    })();
  }, [authorized]);

  if (!authorized) return null;

  const totalUsers = profiles.length;
  const totalAds = ads.length;
  const vipCount = profiles.filter((p) => p.plan && p.plan !== "Free").length;
  const revenue = profiles.reduce((sum, p) => {
    const plan = PLANS.find((x) => x.name === p.plan);
    return sum + (plan?.price ?? 0);
  }, 0);
  const ctr = ads.length ? ads.reduce((s, a) => s + Number(a.ctr || 0), 0) / ads.length : 0;
  const onlineApprox = Math.max(1, Math.round(totalUsers * 0.18));

  const log = (text: string, kind: "info" | "warn" | "ok" = "info") =>
    setLogs((l) => [{ time: new Date().toLocaleTimeString(), text, kind }, ...l].slice(0, 60));

  const setUserPlan = async (id: string, plan: string) => {
    const { error } = await supabase.from("profiles").update({ plan }).eq("id", id);
    if (error) return toast.error(error.message);
    setProfiles((ps) => ps.map((p) => (p.id === id ? { ...p, plan } : p)));
    toast.success(`Plano atualizado para ${plan}`);
    log(`Plano de ${id.slice(0, 8)} alterado para ${plan}`, "ok");
  };

  const banUser = async (id: string) => {
    const { error } = await supabase.from("profiles").update({ plan: "Free", ads_used: 0 }).eq("id", id);
    if (error) return toast.error(error.message);
    setProfiles((ps) => ps.map((p) => (p.id === id ? { ...p, banned: true, plan: "Free" } : p)));
    toast.success("Usuário banido (rebaixado)");
    log(`Usuário ${id.slice(0, 8)} banido`, "warn");
  };

  const exit = () => {
    sessionStorage.removeItem(UNLOCK_KEY);
    toast.success("Sessão admin encerrada");
    navigate({ to: "/" });
  };

  const filteredUsers = profiles.filter((p) =>
    !query ? true : p.username?.toLowerCase().includes(query.toLowerCase()) || p.id.includes(query)
  );
  const filteredAds = ads.filter((a) =>
    !query ? true : a.title?.toLowerCase().includes(query.toLowerCase()) || a.category?.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="sticky top-0 z-30 border-b bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
          <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-primary glow-yellow">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <div className="leading-tight">
            <div className="text-base font-extrabold">Painel Admin</div>
            <div className="text-xs text-muted-foreground">Néctar Agency · acesso privilegiado</div>
          </div>
          <Badge className="ml-2 hidden bg-primary/15 text-primary hover:bg-primary/15 sm:inline-flex">SECRETO</Badge>
          <div className="ml-auto flex items-center gap-2">
            <Link to="/admin/pagaments">
              <Button variant="outline" size="sm">
                <DollarSign className="mr-1 h-4 w-4" /> Pagamentos
              </Button>
            </Link>
            <Button variant="outline" size="sm" onClick={exit}>
              <LogOut className="mr-1 h-4 w-4" /> Sair
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6 lg:py-8">
        <section className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <StatCard icon={Activity} label="Online" value={onlineApprox} accent />
          <StatCard icon={Users} label="Usuários" value={totalUsers} />
          <StatCard icon={Megaphone} label="Anúncios" value={totalAds} />
          <StatCard icon={Crown} label="VIPs" value={vipCount} />
          <StatCard icon={DollarSign} label="Arrecadado" value={Math.round(revenue)} suffix=" R$" accent />
          <StatCard icon={TrendingUp} label="CTR médio" value={Math.round(ctr * 10) / 10} suffix="%" />
        </section>

        <Card className="p-4 sm:p-5">
          <div className="flex flex-wrap items-center gap-2">
            {(["users", "ads", "logs"] as const).map((t) => (
              <Button
                key={t}
                size="sm"
                variant={tab === t ? "default" : "outline"}
                onClick={() => setTab(t)}
                className="capitalize"
              >
                {t === "users" ? "Usuários" : t === "ads" ? "Anúncios" : "Logs do sistema"}
              </Button>
            ))}
            {tab !== "logs" && (
              <div className="relative ml-auto w-full max-w-xs">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar..." className="pl-9" />
              </div>
            )}
          </div>

          <div className="mt-5">
            {loading ? (
              <p className="py-10 text-center text-sm text-muted-foreground">Carregando...</p>
            ) : tab === "users" ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b text-left text-xs uppercase tracking-wider text-muted-foreground">
                      <th className="py-2 pr-4">Usuário</th>
                      <th className="py-2 pr-4">Plano</th>
                      <th className="py-2 pr-4">Anúncios</th>
                      <th className="py-2 pr-4">Status</th>
                      <th className="py-2 pr-4 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((p) => (
                      <tr key={p.id} className="border-b last:border-0 hover:bg-muted/40">
                        <td className="py-3 pr-4">
                          <div className="font-medium">{p.username || "—"}</div>
                          <div className="font-mono text-xs text-muted-foreground">{p.id.slice(0, 8)}</div>
                        </td>
                        <td className="py-3 pr-4">
                          <select
                            value={p.plan}
                            onChange={(e) => setUserPlan(p.id, e.target.value)}
                            className="rounded-md border bg-background px-2 py-1 text-xs"
                          >
                            {PLANS.map((pl) => (
                              <option key={pl.name} value={pl.name}>{pl.name}</option>
                            ))}
                          </select>
                        </td>
                        <td className="py-3 pr-4">{p.ads_used}</td>
                        <td className="py-3 pr-4">
                          {p.banned ? (
                            <Badge variant="destructive">Banido</Badge>
                          ) : (
                            <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                              <CheckCircle2 className="mr-1 h-3 w-3" /> Ativo
                            </Badge>
                          )}
                        </td>
                        <td className="py-3 pr-4 text-right">
                          <Button size="sm" variant="outline" onClick={() => banUser(p.id)}>
                            <Ban className="mr-1 h-3 w-3" /> Banir
                          </Button>
                        </td>
                      </tr>
                    ))}
                    {filteredUsers.length === 0 && (
                      <tr><td colSpan={5} className="py-10 text-center text-muted-foreground">Nenhum usuário</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            ) : tab === "ads" ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b text-left text-xs uppercase tracking-wider text-muted-foreground">
                      <th className="py-2 pr-4">Anúncio</th>
                      <th className="py-2 pr-4">Categoria</th>
                      <th className="py-2 pr-4">Views</th>
                      <th className="py-2 pr-4">CTR</th>
                      <th className="py-2 pr-4">VIP</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAds.map((a) => (
                      <tr key={a.id} className="border-b last:border-0 hover:bg-muted/40">
                        <td className="py-3 pr-4 font-medium">{a.title}</td>
                        <td className="py-3 pr-4 text-muted-foreground">{a.category}</td>
                        <td className="py-3 pr-4">{a.views}</td>
                        <td className="py-3 pr-4">{Number(a.ctr).toFixed(1)}%</td>
                        <td className="py-3 pr-4">
                          {a.vip ? (
                            <Badge className="bg-secondary text-primary hover:bg-secondary">VIP</Badge>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                      </tr>
                    ))}
                    {filteredAds.length === 0 && (
                      <tr><td colSpan={5} className="py-10 text-center text-muted-foreground">Nenhum anúncio</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="rounded-lg border bg-muted/40 p-4 font-mono text-xs">
                <div className="mb-2 flex items-center gap-2 text-muted-foreground">
                  <ScrollText className="h-3 w-3" /> System logs
                </div>
                <div className="space-y-1">
                  {logs.map((l, i) => (
                    <div key={i} className="flex gap-2">
                      <span className="text-muted-foreground">{l.time}</span>
                      <span
                        className={
                          l.kind === "ok" ? "text-emerald-600"
                            : l.kind === "warn" ? "text-amber-600"
                            : "text-foreground"
                        }
                      >
                        ›
                      </span>
                      <span>{l.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-lg font-extrabold">Logística da Plataforma</h2>
          <p className="mt-1 text-sm text-muted-foreground">Visão geral administrativa da Néctar Agency.</p>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            <div className="rounded-xl border bg-muted/30 p-4">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Por que a Néctar foi criada?</div>
              <p className="mt-1 text-sm">Para todo mundo divulgar livremente.</p>
            </div>
            <div className="rounded-xl border bg-muted/30 p-4">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Dono</div>
              <p className="mt-1 text-sm">Maicon Santos · fundador & administrador</p>
            </div>
            <div className="rounded-xl border bg-muted/30 p-4">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Missão</div>
              <p className="mt-1 text-sm">Conectar crescimento e divulgação de forma livre e profissional.</p>
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
}
