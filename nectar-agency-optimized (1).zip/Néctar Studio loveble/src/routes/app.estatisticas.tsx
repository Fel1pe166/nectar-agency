import { createFileRoute } from "@tanstack/react-router";
import { BarChart3, TrendingUp, Eye, MousePointerClick } from "lucide-react";

export const Route = createFileRoute("/app/estatisticas")({
  component: Estatisticas,
});

const blocks = [
  { label: "Visualizações totais", value: "284.310", icon: Eye, trend: "+22.4%" },
  { label: "Cliques", value: "18.940", icon: MousePointerClick, trend: "+12.1%" },
  { label: "CTR médio", value: "8.4%", icon: TrendingUp, trend: "+1.2 pts" },
  { label: "Conversões", value: "2.108", icon: BarChart3, trend: "+9.6%" },
];

function Estatisticas() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Estatísticas</h1>
        <p className="text-sm text-muted-foreground">Acompanhe a performance dos seus anúncios em tempo real.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {blocks.map((b) => (
          <div key={b.label} className="rounded-2xl border bg-card p-5 card-hover">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15">
              <b.icon className="h-5 w-5" />
            </span>
            <p className="mt-4 text-xs uppercase tracking-wider text-muted-foreground">{b.label}</p>
            <p className="mt-1 text-3xl font-bold">{b.value}</p>
            <p className="mt-1 text-xs text-emerald-600">{b.trend}</p>
          </div>
        ))}
      </div>
      <div className="rounded-2xl border bg-card p-6">
        <h2 className="text-lg font-semibold">Visualizações nos últimos 30 dias</h2>
        <div className="mt-6 flex h-64 items-end gap-1.5">
          {Array.from({ length: 30 }).map((_, i) => {
            const h = 25 + Math.round(Math.abs(Math.sin(i / 2.2)) * 75);
            return <div key={i} className="flex-1 rounded-t bg-gradient-to-t from-primary/30 to-primary" style={{ height: `${h}%` }} />;
          })}
        </div>
      </div>
    </div>
  );
}
