# Néctar Agency

## Deploy

- Netlify
- Vercel
- Render

### Build
```bash
npm install
npm run build
```

### Preview
```bash
npm run dev
```
